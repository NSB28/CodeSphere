package com.example.myapplication;

import android.app.Activity;

public class krus extends Activity {
}
